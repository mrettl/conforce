"""
This package contains code that runs only in Abaqus Python, but not in Python 3.
"""

import logging

logging.basicConfig()
LOGGER = logging.getLogger(__name__)